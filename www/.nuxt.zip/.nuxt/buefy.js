import Vue from 'vue'
import Buefy from 'buefy'

Vue.use(Buefy, {
  "css": true,
  "materialDesignIcons": true,
  "materialDesignIconsHRef": "//cdn.materialdesignicons.com/2.4.85/css/materialdesignicons.min.css"
})