import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _0b751c33 = () => interopDefault(import('..\\pages\\about.vue' /* webpackChunkName: "pages_about" */))
const _051bafc6 = () => interopDefault(import('..\\pages\\contact.vue' /* webpackChunkName: "pages_contact" */))
const _205f95e7 = () => interopDefault(import('..\\pages\\faqs.vue' /* webpackChunkName: "pages_faqs" */))
const _d2e36718 = () => interopDefault(import('..\\pages\\join.vue' /* webpackChunkName: "pages_join" */))
const _0ebdea95 = () => interopDefault(import('..\\pages\\process.vue' /* webpackChunkName: "pages_process" */))
const _bfc0aa4c = () => interopDefault(import('..\\pages\\services\\index.vue' /* webpackChunkName: "pages_services_index" */))
const _61e16901 = () => interopDefault(import('..\\pages\\services\\_title.vue' /* webpackChunkName: "pages_services__title" */))
const _2b2cf6f8 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _0b751c33,
    name: "about"
  }, {
    path: "/contact",
    component: _051bafc6,
    name: "contact"
  }, {
    path: "/faqs",
    component: _205f95e7,
    name: "faqs"
  }, {
    path: "/join",
    component: _d2e36718,
    name: "join"
  }, {
    path: "/process",
    component: _0ebdea95,
    name: "process"
  }, {
    path: "/services",
    component: _bfc0aa4c,
    name: "services"
  }, {
    path: "/services/:title",
    component: _61e16901,
    name: "services-title"
  }, {
    path: "/",
    component: _2b2cf6f8,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
